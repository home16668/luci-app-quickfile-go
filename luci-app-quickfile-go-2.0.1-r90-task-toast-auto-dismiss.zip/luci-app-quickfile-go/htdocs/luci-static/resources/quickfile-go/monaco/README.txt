QuickFile-Go local Monaco Editor resources (expanded common-language edition).

This directory contains a reduced Monaco Editor build for local/offline use.
It keeps the core editor plus languages commonly used to edit OpenWrt, scripts,
and source/config files while avoiding the full upstream Monaco footprint.

Bundled language examples:
- shell, PowerShell, lua, go, python, php, ruby, rust, java, swift
- html, css, javascript, TypeScript
- ini/conf, xml, yaml, markdown, sql, dockerfile, c/cpp
- json/html/css/TypeScript workers required by the bundled editor features

Extra local tokenizer support:
- The Monaco resource set used as the source does not ship standalone TOML or
  Makefile basic-language modules. QuickFile-Go registers small offline tokenizers
  from quickfile-go.js for .toml, Makefile and *.mk files.

If you need the complete Monaco package, replace this directory with a full
Monaco `min/vs` tree under:
  htdocs/luci-static/resources/quickfile-go/monaco/vs/
